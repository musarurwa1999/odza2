var mapView = new ol.View({
    center: ol.proj.fromLonLat([30.93361,  -17.89722]),
    zoom: 10
});

var map = new ol.Map({
    target: 'map',
    view: mapView,
    controls: []
});

var noneTile = new ol.layer.Tile({
    title: 'None',
    type: 'base',
    visible: false
});

var osmTile = new ol.layer.Tile({
    title: 'Open Street Map',
    visible: true,
    type: 'base',
    source: new ol.source.OSM()
});

map.addLayer(osmTile);

var Manhole = new ol.layer.Tile({
    title: "Manhole Budiriro",
    source: new ol.source.TileWMS({
        url: 'http://localhost:8080/geoserver/odz23/wms',
        params: { "LAYERS": 'odz23:manhole' },
        serverType: 'geoserver',
        visible: true
    })
});

map.addLayer(Manhole);

var Sewer = new ol.layer.Tile({
    title: "Sewer Budiriro",
    source: new ol.source.TileWMS({
        url: 'http://localhost:8080/geoserver/GISSimplified/wms',
        params: { 'LAYERS': 'GISSimplified:india_st', 'TILED': true },
        serverType: 'geoserver',
        visible: true
    })
});

map.addLayer(Sewer);



var layerSwitcher = new ol.control.LayerSwitcher({
    activationMode: 'click',
    startActive: false,
    groupSelectStyle: 'children'
});

map.addControl(layerSwitcher);



